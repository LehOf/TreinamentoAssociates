﻿using System;
using System.Collections.Generic;

namespace Desafio16
{
    class Sapo
    {
        private int _alturaSapo { get; set; }
        private int _quantidadesCanos { get; set; }
        private int[] _alturaCanos { get; set; }

        public Sapo(int altura, int quantidadesCanos)
        {
            _alturaSapo = altura;
            _quantidadesCanos = quantidadesCanos;
        }

        public string PreenchendoAlturaDoCano()
        {
            var Resultado = "";
            var valor = 0;
            var anterior = 0;
            int[] _alturaCanos = new int[_quantidadesCanos];

            Console.Write("Digite as alturas dos canos: ");
            string[] AlturaDosCanos = Console.ReadLine().Split(' ');

            _alturaCanos = new int[_quantidadesCanos];

            for (int i = 0; i < _quantidadesCanos; i++)
            {
                _alturaCanos[i] = int.Parse(AlturaDosCanos[i]); //atribuindo a altura do cano para a var alturaCanos

                if (Math.Abs(anterior - _alturaCanos[i]) >= _alturaSapo)
                {
                    break;
                }
                else
                {
                    anterior = _alturaCanos[i];
                    valor++;
                }
            }

            if (_quantidadesCanos == valor)
            {
                Resultado = "YOU WIN";
            }
            else
            {
                Resultado = "GAME OVER";
            }

            return Resultado;
        }
    }
}
